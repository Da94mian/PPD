import pygame, random
pygame.init()

#Set display window
WIDTH = 1200
HEIGHT = 700
display_surface = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Little Monster Hunter")

#Set FPS and clock
FPS= 60
clock = pygame.time.Clock()

#Define classes
class Game():
    """A class to controll gameplay"""
    def __init__(self, player, monster_group):
        #Set game values
        self.username = ''
        self.score = 0
        self.round_number = 0

        self.round_time = 0
        self.frame_count = 0

        self.player = player
        self.monster_group = monster_group

        #Set sounds and music
        self.next_level_sound = pygame.mixer.Sound("assety\\next_level.wav")
        
        #Set font
        self.font= pygame.font.Font("assety\\HalloweenNight.ttf", 24)
        
        #Set images
        demon_image = pygame.image.load("assety\\demon.png")
        harpy_image = pygame.image.load("assety\\harpy.png")
        purple_image = pygame.image.load("assety\\purple_monster.png")
        leszy_image = pygame.image.load("assety\\leszy.png")
        self.target_monster_images = [demon_image, harpy_image, purple_image, leszy_image]

        self.target_monster_type = random.randint(0,3)
        self.target_monster_image = self.target_monster_images[self.target_monster_type]

        self.target_monster_rect = self.target_monster_image.get_rect()
        self.target_monster_rect.centerx = WIDTH//2
        self.target_monster_rect.top = 30

    def update(self):
        """Update our game object"""
        self.frame_count +=1
        if self.frame_count == FPS:
            self.round_time +=1
            self.frame_count = 0

        #check for collisions
        self.check_collisions()

    def draw(self):
        """Draw the HUD and other to the display"""
        #Set kolor
        WHITE = (255,255,255)
        RED = (255, 0, 0)
        HARPY = (237, 230, 230)
        PURPLE = (227, 73, 243)
        LESZY = (102, 80, 61)

        #Add monster colors to a list where the index of the color matches target_monster_images
        colors = [RED, HARPY, PURPLE, LESZY]

        #Set tekst
        catch_text = self.font.render("Current Catch", True, WHITE)
        catch_rect = catch_text.get_rect()
        catch_rect.centerx = WIDTH//2
        catch_rect.top = 5

        score_text = self.font.render(f"Score: {str(self.score)}", True, WHITE)
        score_rect = score_text.get_rect()
        score_rect.topleft = (5,5)

        lives_text = self.font.render(f"Lives: {str(self.player.lives)}", True, WHITE)
        lives_rect = lives_text.get_rect()
        lives_rect.topleft = (5,35)

        round_text = self.font.render(f"Round: {str(self.round_number)}", True, WHITE)
        round_rect = round_text.get_rect()
        round_rect.topleft = (5,65)

        time_text = self.font.render(f"Time: {str(self.round_time)}", True, WHITE)
        time_rect = time_text.get_rect()
        time_rect.topright = (WIDTH-10,5)

        blinks_text = self.font.render(f"Blinks left: {str(self.player.blinks)}", True, WHITE)
        blinks_rect = blinks_text.get_rect()
        blinks_rect.topright = (WIDTH-10,35)

        username_text = self.font.render(f"{self.username}",True,WHITE)
        username_rect= username_text.get_rect()
        username_rect.topright = (WIDTH-10, 65)
        #Blit the HUD
        display_surface.blit(catch_text, catch_rect)
        display_surface.blit(score_text, score_rect)
        display_surface.blit(round_text, round_rect)
        display_surface.blit(time_text, time_rect)
        display_surface.blit(lives_text, lives_rect)
        display_surface.blit(blinks_text, blinks_rect)
        display_surface.blit(self.target_monster_image, self.target_monster_rect)
        display_surface.blit(username_text,username_rect)

        pygame.draw.rect(display_surface, colors[self.target_monster_type], (WIDTH//2-32, 30, 64, 64), 2)
        pygame.draw.rect(display_surface, colors[self.target_monster_type], (0, 100, WIDTH, HEIGHT-200), 4)

    def check_collisions(self):
        """Check for collision between player and monsters"""
        #Check for collision between player and idividual monster
        #We must test the type of the monster to see if it matches the type of our target monster
        collided_monster = pygame.sprite.spritecollideany(self.player, self.monster_group)
        
        #We collided with a monster
        if collided_monster:
            #Caught the correct monster
            if collided_monster.type == self.target_monster_type:
                self.score += 100*self.round_number
                #remove caught monster
                collided_monster.remove(self.monster_group)
                if (self.monster_group):
                    #There are more monsters to catch
                    self.player.catch_sound.play()
                    self.choose_new_target()
                else:
                    #The round is completed
                    self.player.reset()
                    self.start_new_round()
            else:
                #Caught the wrong monster
                self.player.die_sound.play()
                self.player.lives -= 1
                #Check for game over
                if self.player.lives <= 0:
                    self.pause_game(f"{self.username.capitalize()} your final score is {str(self.score)}", "Press 'ENTER' to continue!")
                    self.reset_game()
                self.player.reset()

    def start_new_round(self):
        """Populate board with new monsters"""
        #Provide a score bonus based on how quickly the round was finished
        self.score+= int(10000*self.round_number//(1+self.round_time))

        #Reset round values
        self.round_time = 0
        self.frame_count = 0
        self.round_number += 1
        self.player.blinks +=1

        #Remove any remaining monsters from a game reset
        for monster in self.monster_group:
            self.monster_group.remove(monster)

        #Add monsters to the monster group
        for i in range(self.round_number):
            self.monster_group.add(Monster(random.randint(0, WIDTH-64), random.randint(100, HEIGHT - 164), self.target_monster_images[0], 0))
            self.monster_group.add(Monster(random.randint(0, WIDTH-64), random.randint(100, HEIGHT - 164), self.target_monster_images[1], 1))
            self.monster_group.add(Monster(random.randint(0, WIDTH-64), random.randint(100, HEIGHT - 164), self.target_monster_images[2], 2))
            self.monster_group.add(Monster(random.randint(0, WIDTH-64), random.randint(100, HEIGHT - 164), self.target_monster_images[3], 3))

        #Choose a new target monster
        self.choose_new_target()
        self.next_level_sound.play()

    def choose_new_target(self):
        """Choose a new target monster for the player"""
        target_monster = random.choice(self.monster_group.sprites())
        self.target_monster_type = target_monster.type
        self.target_monster_image = target_monster.image

    def pause_game(self, main_text, sub_text):
        """Pause the game"""
        global running
        #Set color
        WHITE =(255,255,255)
        BLACK = (0,0,0)

        #Create the main pause text
        main_text = self.font.render(main_text, True, WHITE)
        main_rect = main_text.get_rect()
        main_rect.center = (WIDTH//2, HEIGHT//2)

        #Create the sub pause text
        sub_text = self.font.render(sub_text, True, WHITE)
        sub_rect = sub_text.get_rect()
        sub_rect.center = (WIDTH//2, HEIGHT//2+64)

        #Display the paused text
        display_surface.fill(BLACK)
        display_surface.blit(main_text, main_rect)
        display_surface.blit(sub_text, sub_rect)
        pygame.display.update()

        #Pause the game
        is_paused = True
        while is_paused:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        is_paused = False
                if event.type ==pygame.QUIT:
                    is_paused = False
                    running = False

    def start_game(self, main_text, sub_text, sub_text2, sub_text3):
        """Start the game"""
        global running
        #Set color
        WHITE =(255,255,255)
        BLACK = (0,0,0)

        #Create the main text
        main_text = self.font.render(main_text, True, WHITE)
        main_rect = main_text.get_rect()
        main_rect.center = (WIDTH//2, HEIGHT//2 - 64)

        #Create the sub text
        sub_text = self.font.render(sub_text, True, WHITE)
        sub_rect = sub_text.get_rect()
        sub_rect.center = (WIDTH//2, HEIGHT//2)
        sub_text2 = self.font.render(sub_text2, True, WHITE)
        sub_rect2 = sub_text2.get_rect()
        sub_rect2.center = (WIDTH//2, HEIGHT//2+64)
        sub_text3 = self.font.render(sub_text3, True, WHITE)
        sub_rect3 = sub_text3.get_rect()
        sub_rect3.center = (WIDTH//2, HEIGHT//2+128)

        #Display text
        display_surface.fill(BLACK)
        display_surface.blit(main_text, main_rect)
        display_surface.blit(sub_text, sub_rect)
        display_surface.blit(sub_text2, sub_rect2)
        display_surface.blit(sub_text3, sub_rect3)
        pygame.display.update()

        is_started = True
        while is_started:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        is_started = False
                if event.type ==pygame.QUIT:
                    is_started = False
                    running = False
            
            display_surface.fill(BLACK)

            inputting = True
        
        while inputting:
            text = self.font.render("Enter your name:", True, (255, 255, 255))
            text_rect= text.get_rect()
            text_rect.center=(WIDTH//2, HEIGHT//2-25)
            display_surface.blit(text, text_rect)
            pygame.draw.rect(display_surface, (0, 0, 0), pygame.Rect(50, 100, 300, 30))
            name_text = self.font.render(self.username, True, (255, 255, 255))
            name_text_rect = name_text.get_rect()
            name_text_rect.center = (WIDTH//2, HEIGHT//2+25)
            display_surface.blit(name_text, name_text_rect)
            pygame.display.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                elif event.type==pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        inputting = False
                    elif event.key == pygame.K_BACKSPACE:
                        self.username = self.username[:-1]
                        display_surface.blit(text, text_rect)
                        display_surface.blit(name_text, name_text_rect)
                        display_surface.fill(BLACK)
                    else:
                        self.username += event.unicode
                        display_surface.blit(text, text_rect)
                        display_surface.blit(name_text, name_text_rect)
                        display_surface.fill(BLACK)
        return self.username
    
    def reset_game(self):
        """Reset the game"""
        self.score = 0
        self.round_number = 0

        self.player.lives = 5
        self.player.blinks = 2
        self.player.reset()

        self.start_new_round()

class Player(pygame.sprite.Sprite):
    """A player class that the user can control"""
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("assety\\paladin.png")
        self.rect = self.image.get_rect()
        self.rect.centerx=WIDTH//2
        self.rect.bottom=HEIGHT

        self.lives = 5
        self.blinks = 2
        self.velocity = 8
        
        self.catch_sound = pygame.mixer.Sound("assety\\catch.wav")
        self.die_sound = pygame.mixer.Sound("assety\\die.wav")
        self.blinks_sound = pygame.mixer.Sound("assety\\blink.wav")

    def update(self):
        """Update the player"""
        keys = pygame.key.get_pressed()

        #move the player within the bounds of the screen
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.velocity
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.velocity
        if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT-100:
            self.rect.y += self.velocity
        if keys[pygame.K_UP] and self.rect.top > 100:
            self.rect.y -= self.velocity

    def blink(self):
        """Teleports the player to the bottom 'safe zone'"""
        if self.blinks > 0:
            self.blinks -=1
            self.blinks_sound.play()
            self.rect.bottom = HEIGHT

    def reset(self):
        """Resets the player position"""
        self.rect.centerx = WIDTH//2
        self.rect.bottom = HEIGHT


class Monster(pygame.sprite.Sprite):
    def __init__(self, x, y, image, monster_type):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

        #moster type is int 0 = blue, 1 = green, 2 = purple, 3 = yellow
        self.type = monster_type

        #Set random motion
        self.dx = random.choice([-1,1])
        self.dy = random.choice([-1,1])
        self.velocity = random.randint(1,5)

    def update(self):
        """Update the monster"""
        self.rect.x += self.dx*self.velocity
        self.rect.y += self.dy*self.velocity

        #Bounce the monster off the edges of display
        if self.rect.left <= 0 or self.rect.right >= WIDTH:
            self.dx = -1*self.dx
        if self.rect.top <= 100 or self.rect.bottom >= HEIGHT-100:
            self.dy = -1*self.dy

#Create a player groupe and player object:
my_player_group = pygame.sprite.Group()
my_player = Player()
my_player_group.add(my_player)

#Create a monster groupe and monster object:
my_monster_group = pygame.sprite.Group()

#Create game object
my_game=Game(my_player, my_monster_group)
my_game.start_game("Little Monster Hunter", "Your job is to catch monster from target picture.", "In the case of emergency you can press space to teleport into safe zone.", "Good luck during hunting! Press 'ENTER' to start. Press 'ESC' to pause the game.")
my_game.start_new_round()

#The main game loop
running =True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
        #Player wants to teleport
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                my_player.blink()
            if event.key == pygame.K_ESCAPE:
                my_game.pause_game("Little Monster Hunter", "Press 'ENTER' to continue")
    
    #Fill the display
    display_surface.fill((50, 98, 115))
    
    #update and draw sprite groups
    my_player_group.update()
    my_player_group.draw(display_surface)
    my_monster_group.update()
    my_monster_group.draw(display_surface)

    #update and draw the game
    my_game.update()
    my_game.draw()

    #Update display and tick the clock
    pygame.display.update()
    clock.tick(FPS)

pygame.quit()